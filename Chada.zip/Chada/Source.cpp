// Paul Velazquez
// Chada Tech Clocks 
// CS 210 Programming Languages
// 3/15/2022

#include <iostream>
using namespace std;
#include <iomanip>

// Parent class for the two clocks
class Time {
	public:
		int hour;
		int minute;
		int second;
		string ampm;
};

// Derives from class Time, uses AM/PM and cycles from 12 to 1
class hours12 : public Time {

	public: hours12(int h, int m, int s)
		{
			hour = h;
			minute = m;
			second = s;
			ampm = "PM";
		}

	void addHour() // Increments the hour, cycling as needed.
		  {
			  if (hour == 11) {
				  hour += 1;
				  if (ampm == "AM"){
					  ampm = "PM";
				  }
				  else {
					  ampm = "AM";
				  }
			  }
			  else if (hour == 12) {
				  hour = 1;
			  }
			  else {
				  hour += 1;
			  }
		  }

	void addMinute() // Increments the minute, cycling as needed.
		{
			if (minute == 59) {
				minute = 0;
				addHour();
			}
			else {
				minute += 1;
			}
		}

	void addSecond() // Increments the second, cycling as needed.
	{
		if (second == 59) {
			second = 0;
			addMinute();
		}
		else {
			second += 1;
		}
	}
	
	
};

// Also derives from class Time, does not use AM/PM and cycles from 24 to 0
class hours24 : public Time {

	public: hours24(int h, int m, int s)
		{
			hour = h;
			minute = m;
			second = s;
		}

	void addHour() // Increments the hour, cycling as needed.
		{
			if (hour == 23) {
				hour = 0;
			}
			else {
				hour += 1;
			}
		}

	  void addMinute() // Increments the minute, cycling as needed.
	  {
		  if (minute == 59) {
			  minute = 0;
			  addHour();
		  }
		  else {
			  minute += 1;
		  }
	  }

	  void addSecond() // Increments the second, cycling as needed.
	  {
		  if (second == 59) {
			  second = 0;
			  addMinute();
		  }
		  else {
			  second += 1;
		  }
	  }
	  
};

// displayTime function displays formatted time
void displayTime(hours12 standard, hours24 military)
{
	// Using setw and setfill to place a leading zero in front of any single digit number
	cout << "***************** *****************" << endl;
	cout << "* 12-Hour Clock * * 24-Hour Clock *" << endl;
	cout << "*  " << setw(2) << setfill('0') << standard.hour << ":" << setw(2) << setfill('0') << standard.minute << ":" ;
	cout << setw(2) << setfill('0') << standard.second <<  " " << standard.ampm << "  * ";
	cout << "*   " << setw(2) << setfill('0') << military.hour << ":" << setw(2) << setfill('0') << military.minute << ":";
	cout << setw(2) << setfill('0') << military.second << "    *" << endl;
	cout << "***************** *****************" << endl;
}

// In main we instantiate the clocks, set starting values, output the menu, and run menu operations via the methods of hours12 and hours24.
// I tried separating the entire menu into its own function outside of main, but started running into errors that I could not figure out, so I put it back.
int main() {
	hours12 standardClock(11, 59, 59);
	hours24 militaryClock(23, 59, 59);
	displayTime(standardClock, militaryClock);
	while (true)
		{
		cout << "***********************" << endl;
		cout << "* 1 - Add One Hour    *" << endl;
		cout << "* 2 - Add One Minute  *" << endl;
		cout << "* 3 - Add One Second  *" << endl;
		cout << "* 4 - Exit Program    *" << endl;
		cout << "***********************" << endl;

		int option;
		cin >> option;
		switch (option)
		{
		case 1:
			standardClock.addHour();
			militaryClock.addHour();
			displayTime(standardClock, militaryClock);
			break;
		case 2:
			standardClock.addMinute();
			militaryClock.addMinute();
			displayTime(standardClock, militaryClock);
			break;
		case 3:
			standardClock.addSecond();
			militaryClock.addSecond();
			displayTime(standardClock, militaryClock);
			break;
		case 4:
			exit(1);
			break;
		default:
			cout << "Please enter 1 through 4 only." << endl;
			displayTime(standardClock, militaryClock);
			break;
		}
	}
}