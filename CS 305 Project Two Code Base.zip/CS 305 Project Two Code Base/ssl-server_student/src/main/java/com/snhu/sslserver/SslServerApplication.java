package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {
	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{
    @RequestMapping("/hash")
    public String myHash(){    
    	MessageDigest messageDigest = null; // instantiate MessageDigest
    	String data = "Paul Velazquez: Hello World Check Sum!";	// String data
    	String checkSum = null;     
		try {
			messageDigest = MessageDigest.getInstance("SHA-256"); // initialize object with SHA-256
		} catch (NoSuchAlgorithmException e) {
			// Auto-generated catch block
			e.printStackTrace();
		}  									
    	messageDigest.update(data.getBytes());		// pass "Paul Velazquez: Hello World Check Sum!" to messageDigest
	byte[] digest = messageDigest.digest();		// run the hash algorithm
	checkSum = this.bytesToHex(digest);		// create hash value    
	// return formatted string
        return "<p>Data: " + data + "<br>Algorithm cipher: SHA-256" + "<br>Checksum hash value: " + checkSum + "</p>"; // Output algorithm name and checkSum value
    }
   // Converts a byte array to a hexadecimal string
   public String bytesToHex(byte[] bytes) {
       StringBuilder springBuilder = new StringBuilder();
       // loop through byte array
       for (byte hashByte : bytes) {
           int intVal = 0xff & hashByte;
           if (intVal < 0x10) {
        	   springBuilder.append('0');	// append elements
           }
           springBuilder.append(Integer.toHexString(intVal));
       }
       return springBuilder.toString();		// return hexadecimal string
   }
}